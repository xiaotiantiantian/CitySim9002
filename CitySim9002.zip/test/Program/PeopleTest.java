/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Program;

import Program.People.*;
import java.util.Random;
import junit.framework.Assert;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 *
 * @author Zhirun Tian
 */
public class PeopleTest {
    
    public PeopleTest() {
    }

    /**
     * Test of Visit method, of class People.
     */
    @Test
    public void testVisit() {
//        System.out.println("Visit");
//        People.VisitorType vt = null;
//        int seed = 0;
//        int times = 0;
//        People instance = new People();
//        int expResult = 0;
//        int result = instance.Visit(vt, seed, times);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
    
    //test the function getcode of class Location
    @Test
    public void FromEnumLocationGetTest(){
        Location loc = Location.CathedralOfLearning;
        Assert.assertEquals(loc.getCode(), 1);
        
    }
    
    //test double
    //in the function Visit, it use external class Random
    //so just use mockito to mock the class and return certain vaule
    //then look would the visitor leave the 1st time
    @Test
    public void VisitNotLeaveFirstTimeTest(){
        boolean FirstVisit = true;
        Random mockRand = mock(Random.class);
        when(mockRand.nextInt(anyInt())).thenReturn(1);
        Location lo;
        lo = Location.fromCode(mockRand.nextInt(4) + 1);
        while ((lo == Location.Leave) && FirstVisit) {
            //lo:location 1-5 
            lo = Location.fromCode(mockRand.nextInt(4) + 1);
        }
        Assert.assertFalse(lo==Location.Leave);
    }
    
    @Test
    public void FromEnumLocationSetByIntTest(){
        
    }
    
}
