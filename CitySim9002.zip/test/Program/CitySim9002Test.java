///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package Program;
//
//import Domain.Validator;
//import org.junit.Assert;
//import org.junit.Test;
//import static org.junit.Assert.*;
//import org.mockito.*;
//
///**
// *
// * @author Zhirun Tian
// */
//public class CitySim9002Test {
//
//    public CitySim9002Test() {
//    }
//
//    /**
//     * Test of main method, of class CitySim9002.
//     */
//    @Test
//    public void testMain() {
//        System.out.println("main");
//        String[] args = {"2"};
//        CitySim9002.main(args);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    @Test
//    public void ifArgsGiven2() {
//        
//        Assert.
//        Assert.assertTrue(new Validator().validateNumberOfArguments(new String[]{"1"}));
//    }
//
//}
